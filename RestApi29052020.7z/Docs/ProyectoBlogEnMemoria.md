

- dotnet new webapi -o BlogApi
- cd BlogApi/
– dotnet add package Microsoft.EntityFrameworkCore -v 2.2
– dotnet add package Microsoft.EntityFrameworkCore.SqlServer -v 2.2


– dotnet add package Microsoft.EntityFrameworkCore.Tools -v 2.2
– dotnet add package Pomelo.EntityFrameworkCore.MySql -v 2.2